import json
import boto3

ec2 = boto3.resource('ec2', region_name='us-west-2')

def lambda_handler(event, context):
    instances = ec2.instances.filter(Filters=[{'Name': 'tag:instance_schedule','Values':['yes']}])
    for instance in instances:
        id=instance.id
        ec2.instances.filter(InstanceIds=[id]).stop()
        print("Instance ID is started :- "+instance.id)
    return "success"